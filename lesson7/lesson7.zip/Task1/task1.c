#include <stdio.h>

//-----------------------------

int main(){

  char ch;
	for(ch = 'a'; ch <= 'z'; ch++){

    printf("Code '%c' = %d\n", ch, ch);
	}

  return 0;
}
